# Dokumentasi Plugin Kategori stelloCMS

## Deskripsi
Plugin Kategori adalah modul tambahan untuk sistem stelloCMS yang memungkinkan pengguna untuk mengelola kategori berita. Plugin ini menyediakan kemampuan untuk membuat, mengedit, menghapus, dan menetapkan kategori ke berita di sistem Berita.

## Versi
- 1.0.0

## Fitur Utama

### 1. Manajemen Kategori Lengkap
- **Create (Tambah)**: Membuat kategori baru dengan nama, deskripsi, warna, ikon, dan status aktif
- **Read (Lihat)**: Menampilkan daftar kategori dalam format tabel
- **Update (Edit)**: Mengedit kategori yang sudah ada
- **Delete (Hapus)**: Menghapus kategori dari sistem (dengan verifikasi tidak digunakan di berita)

### 2. Fitur Kategori
- Nama kategori (wajib)
- Deskripsi kategori (opsional)
- Warna kustomisasi (opsional)
- Ikon Font Awesome (opsional)
- Status aktif/non-aktif

### 3. Integrasi dengan Plugin Berita
- Menambahkan dropdown kategori di form tambah/edit berita (jika plugin Kategori terinstal)
- Kategori tidak wajib diisi di form berita
- Jika plugin Kategori tidak terinstal, field kategori tidak muncul di form berita

### 4. Antarmuka Administrasi
- Dashboard untuk pengelolaan kategori
- Form yang mudah digunakan untuk tambah/edit kategori
- Tabel yang responsif untuk menampilkan daftar kategori

## Struktur Plugin

### Struktur Direktori
```
app/Plugins/Kategori/
├── Controllers/
│   └── KategoriController.php
├── Models/
│   └── Kategori.php
├── Views/
│   ├── create.blade.php
│   ├── edit.blade.php
│   ├── index.blade.php
│   └── show.blade.php (opsional)
├── Doc/
│   └── README.md
├── helpers.php
├── install.php
├── plugin.json
└── routes.php
```

## Model dan Database

### Tabel `kategori_berita`

| Kolom | Tipe Data | Deskripsi | Contoh |
|-------|-----------|-----------|---------|
| id | BIGINT (unsigned auto-increment) | Primary key | 1, 2, 3 |
| nama_kategori | VARCHAR(255) | Nama kategori | "Teknologi", "Politik", "Olahraga" |
| deskripsi | TEXT (nullable) | Deskripsi kategori | "Berita terbaru tentang teknologi..." |
| warna | VARCHAR(10) | Kode warna hex untuk tampilan UI | "#007bff", "#28a745" |
| ikon | VARCHAR(50) | Nama ikon Font Awesome | "fas fa-laptop", "fas fa-vote-yea" |
| aktif | BOOLEAN | Status kategori (aktif/tidak) | 1 (aktif), 0 (non-aktif) |
| created_at | TIMESTAMP | Tanggal pembuatan | 2025-01-01 00:00:00 |
| updated_at | TIMESTAMP | Tanggal pembaruan | 2025-01-01 00:00:00 |

### Model Kategori
```php
use App\Plugins\Kategori\Models\Kategori;

// Mendapatkan semua kategori aktif
$kategoris = Kategori::aktif()->get();

// Mendapatkan kategori berdasarkan ID
$kategori = Kategori::find($id);

// Membuat kategori baru
$kategori = Kategori::create([
    'nama_kategori' => 'Teknologi',
    'deskripsi' => 'Berita tentang perkembangan teknologi',
    'aktif' => true
]);
```

## Routing

### Rute Admin
- `GET /panel/kategori` → `KategoriController@index` (nama route: `panel.kategori.index`)
- `GET /panel/kategori/create` → `KategoriController@create` (nama route: `panel.kategori.create`)
- `POST /panel/kategori` → `KategoriController@store` (nama route: `panel.kategori.store`)
- `GET /panel/kategori/{id}` → `KategoriController@show` (nama route: `panel.kategori.show`)
- `GET /panel/kategori/{id}/edit` → `KategoriController@edit` (nama route: `panel.kategori.edit`)
- `PUT /panel/kategori/{id}` → `KategoriController@update` (nama route: `panel.kategori.update`)
- `DELETE /panel/kategori/{id}` → `KategoriController@destroy` (nama route: `panel.kategori.destroy`)

## Integrasi dengan Plugin Berita

### Tampilan Form Berita
Jika plugin Kategori terinstal, maka form berita akan menampilkan:

#### Tambah/Edit Berita
```html
<div class="form-group">
    <label for="kategori_id">Kategori (opsional)</label>
    <select class="form-control @error('kategori_id') is-invalid @enderror" id="kategori_id" name="kategori_id">
        <option value="">-- Pilih Kategori --</option>
        <!-- Daftar kategori aktif -->
    </select>
    @error('kategori_id')
        <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>
```

### Integrasi Otomatis
- Plugin Berita secara otomatis akan mendeteksi keberadaan plugin Kategori
- Jika plugin Kategori tidak terinstal, field kategori akan otomatis disembunyikan dari form
- Field kategori tidak wajib diisi, hanya opsional
- Relasi antara berita dan kategori menggunakan foreign key di tabel berita

### Relasi Database
- Tabel `berita` akan memiliki kolom `kategori_id` (BIGINT unsigned, nullable) sebagai foreign key ke tabel `kategori_berita`
- Relasi one-to-many antara kategori dan berita

## Helper Functions

### helpers.php
```php
// Mendapatkan semua kategori aktif
$kategoris = get_kategori();

// Mendapatkan semua kategori (aktif dan non-aktif)
$all_kategori = get_kategori_all();

// Mendapatkan kategori berdasarkan ID
$kategori = get_kategori_by_id(1);
```

### Helper Availability Check
```php
// Cek apakah plugin Kategori terinstal
if (function_exists('get_kategori')) {
    $kategoriList = get_kategori();
    // Gunakan kategori dalam form
} else {
    // Sembunyikan field kategori dari form
}
```

## Controller Methods

### KategoriController Methods
- `index()` - Menampilkan daftar kategori untuk admin
- `create()` - Menampilkan form tambah kategori
- `store(Request $request)` - Menyimpan kategori baru
- `show($id)` - Menampilkan detail kategori
- `edit($id)` - Menampilkan form edit kategori
- `update(Request $request, $id)` - Memperbarui kategori
- `destroy($id)` - Menghapus kategori
- `getActiveCategories()` - API endpoint untuk mendapatkan kategori aktif

### Validasi Input
Semua input melalui controller divalidasi untuk mencegah data yang tidak valid:
- **nama_kategori**: Wajib, string maksimal 255 karakter
- **deskripsi**: Opsional, string yang bisa panjang
- **warna**: Opsional, string maksimal 10 karakter (kode warna hex)
- **ikon**: Opsional, string maksimal 50 karakter (nama ikon Font Awesome)
- **aktif**: Boolean, default true

## Instalasi dan Penghapusan

### install.php
```php
// Install script otomatis membuat tabel kategori_berita
// Jika tabel sudah ada, skrip akan memperbarui struktur
KategoriInstaller::install();
```

### uninstall.php (tergabung dalam install.php)
```php
// Uninstall script menghapus tabel kategori_berita
KategoriInstaller::uninstall();
```

## Best Practices

### Penamaan Kategori
- Gunakan nama yang deskriptif dan unik
- Gunakan huruf kapital di awal kata
- Jangan gunakan karakter spesial yang tidak diperlukan

### Penggunaan Warna
- Gunakan warna yang kontras dan mudah dibaca
- Pastikan warna konsisten dengan tema situs
- Gunakan warna untuk membantu identifikasi kategori

### Fitur Kategori
- Gunakan status aktif/non-aktif untuk mengontrol visibilitas
- Gunakan deskripsi untuk memberikan informasi tambahan
- Gunakan ikon untuk visualisasi yang lebih baik

### Integrasi dengan Berita
- Pastikan kategori yang tidak digunakan bisa dihapus
- Tampilkan hanya kategori aktif di dropdown
- Tidak wajib mengisi kategori untuk berita

## Troubleshooting

### Kategori Tidak Muncul di Dropdown Berita
- Pastikan plugin Kategori terinstal dengan benar
- Jalankan `php artisan migrate` jika tabel belum dibuat
- Periksa file `helpers.php` bisa diakses
- Pastikan function `get_kategori()` dapat dipanggil

### Error saat Instalasi
- Pastikan struktur direktori plugin benar
- Pastikan file `install.php` memiliki izin yang benar
- Periksa log error untuk informasi lebih lanjut

### Kategori Tidak Bisa Dihapus
- Pastikan kategori tidak sedang digunakan oleh berita
- Periksa relasi foreign key di database

### Cache Issue
- Jalankan `php artisan view:clear` untuk membersihkan cache view
- Jalankan `php artisan route:clear` untuk membersihkan cache route
- Jalankan `php artisan config:clear` untuk membersihkan cache konfigurasi

## Keamanan
- Validasi semua input user
- Gunakan CSRF token untuk setiap form
- Batasi akses hanya untuk pengguna terotentikasi
- Sanitasi input deskripsi untuk mencegah XSS

## Performance
- Gunakan hanya kategori aktif untuk dropdown
- Gunakan eager loading untuk relasi
- Gunakan caching jika diperlukan untuk daftar kategori

## Konfigurasi Plugin

### plugin.json
```json
{
    "name": "Kategori",
    "version": "1.0.0",
    "description": "Plugin untuk mengelola kategori berita",
    "author": "stelloCMS Development Team",
    "author_url": "https://stellocms.com",
    "required_version": "1.0.0",
    "install_script": "install.php",
    "helpers": "helpers.php"
}
```